import requests
import tkinter as tk
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from datetime import datetime
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# Function to fetch Bitcoin price from CoinGecko API
def get_bitcoin_price(currencies):
    url = f"https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies={','.join(currencies)}"
    response = requests.get(url)

    if response.status_code == 200:
        return response.json()['bitcoin']
    else:
        print("Error: Unable to fetch data.")
        return None


# Updated countries and currency codes (including Arab countries)
countries = {
    'USA': 'usd',
    'Canada': 'cad',
    'UK': 'gbp',
    'Germany': 'eur',
    'Australia': 'aud',
    'Japan': 'jpy',
    'India': 'inr',
    'China': 'cny',
    'Brazil': 'brl',
    'Switzerland': 'chf',
    'South Korea': 'krw',
    'Mexico': 'mxn',
    'Jordan': 'jod',
    'Saudi Arabia': 'sar',
    'UAE': 'aed',
    'Egypt': 'egp',
    'Kuwait': 'kwd',
    'Qatar': 'qar',
    'Bahrain': 'bhd',
    'Lebanon': 'lbp',
    'Oman': 'omr',
    'Iraq': 'iqd',
    'Algeria': 'dzd',
    'Tunisia': 'tnd'
}

# List for storing historical prices
historical_prices = []


# Function to fetch and display Bitcoin price in different countries
def update_prices():
    global historical_prices
    prices = get_bitcoin_price([currency for country, currency in countries.items()])
    if prices:
        # Get current time for x-axis (historical graph)
        current_time = datetime.now().strftime("%H:%M:%S")

        # Collect the price for each country
        display_text = ""
        for (country, currency), price in zip(countries.items(), prices.values()):
            display_text += f"{country}: {price} {currency.upper()}\n"

            # Add to historical prices (for graphing)
            historical_prices.append((current_time, price))

        # Update text display in Tkinter window
        label_price.config(text=display_text)

    # Call this function every 5 seconds to update prices
    window.after(5000, update_prices)


# Function to plot the real-time graph
def animate(i):
    if historical_prices:
        # Extract time and prices for plotting
        times = [item[0] for item in historical_prices]
        prices = [item[1] for item in historical_prices]

        # Plot the graph
        ax.clear()
        ax.plot(times, prices, label="Bitcoin Price", color='dodgerblue', linewidth=3)
        ax.set_title("Bitcoin Price in Real-Time", fontsize=18, fontweight='bold')
        ax.set_xlabel("Time", fontsize=14)
        ax.set_ylabel("Price (USD)", fontsize=14)
        ax.tick_params(axis='both', which='major', labelsize=12)


# Create main Tkinter window
window = tk.Tk()
window.title("NetRise Bitcoin Tracker")
window.geometry("800x700")
window.configure(bg='#1E2A47')  # Darker background for sleek look

# Create a frame for content with a modern look
frame = tk.Frame(window, bg='#34495E', padx=20, pady=20)
frame.pack(padx=20, pady=20, fill="both", expand=True)

# Title label with custom font and gradient
title_label = tk.Label(frame, text="NetRise Bitcoin Tracker", font=('Helvetica', 26, 'bold'), fg='white', bg='#34495E')
title_label.pack(pady=10)

# Create label for displaying prices in a modern 'card' style
price_card = tk.Frame(frame, bg='#2C3E50', relief="solid", bd=2, padx=15, pady=15)
price_card.pack(pady=20, fill="x")

label_price = tk.Label(price_card, font=('Helvetica', 14), fg='white', bg='#2C3E50', anchor='w')
label_price.pack(pady=10, fill="x")


# Stylish Start Button with hover effect
def on_enter(e):
    start_button['bg'] = '#E74C3C'  # Change to red on hover


def on_leave(e):
    start_button['bg'] = '#C0392B'  # Change back to original red


start_button = tk.Button(frame, text="Start Tracker", command=update_prices, font=('Helvetica', 14, 'bold'),
                         fg='white', bg='#C0392B', relief="raised", padx=20, pady=10)
start_button.pack(pady=20)
start_button.bind("<Enter>", on_enter)
start_button.bind("<Leave>", on_leave)

# Set up Matplotlib figure for the graph
fig, ax = plt.subplots(figsize=(10, 6), dpi=80)
ani = animation.FuncAnimation(fig, animate, interval=5000)  # Update graph every 5 seconds
plt.tight_layout()

# Create a canvas to embed the Matplotlib graph into Tkinter window
canvas = FigureCanvasTkAgg(fig, master=window)
canvas.get_tk_widget().pack(fill="both", expand=True)

# Run the Tkinter main loop
window.mainloop()
